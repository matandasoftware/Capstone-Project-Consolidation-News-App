#!/bin/bash

# Quick Setup Script for News Application (Linux/macOS)

echo "============================================"
echo "News Application - Quick Setup"
echo "============================================"
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "[1/6] Creating virtual environment..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to create virtual environment"
        echo "Please ensure Python 3 is installed"
        exit 1
    fi
    echo "Virtual environment created successfully!"
else
    echo "[1/6] Virtual environment already exists."
fi
echo ""

# Activate virtual environment
echo "[2/6] Activating virtual environment..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to activate virtual environment"
    exit 1
fi
echo "Virtual environment activated!"
echo ""

# Install dependencies
echo "[3/6] Installing dependencies..."
echo "This may take a few minutes..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    echo ""
    echo "If mysqlclient installation failed, you may need to:"
    echo "  Ubuntu/Debian: sudo apt-get install python3-dev default-libmysqlclient-dev build-essential"
    echo "  macOS: brew install mysql"
    exit 1
fi
echo "Dependencies installed successfully!"
echo ""

# Check database connection
echo "[4/6] Checking Django configuration..."
python manage.py check
if [ $? -ne 0 ]; then
    echo "ERROR: Django configuration check failed"
    echo "Please review the error messages above"
    exit 1
fi
echo "Configuration check passed!"
echo ""

echo "============================================"
echo "IMPORTANT: DATABASE SETUP REQUIRED"
echo "============================================"
echo ""
echo "Before proceeding, ensure you have:"
echo "1. Installed MariaDB/MySQL"
echo "2. Created the database and user (see MARIADB_SETUP.md)"
echo "3. Updated settings.py with correct credentials"
echo ""
echo "To create the database, run these SQL commands:"
echo "  CREATE DATABASE news_app_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
echo "  CREATE USER 'news_app_user'@'localhost' IDENTIFIED BY 'news_app_password';"
echo "  GRANT ALL PRIVILEGES ON news_app_db.* TO 'news_app_user'@'localhost';"
echo "  FLUSH PRIVILEGES;"
echo ""
read -p "Have you completed the database setup? (y/n): " continue
if [ "$continue" != "y" ] && [ "$continue" != "Y" ]; then
    echo ""
    echo "Please complete database setup and run this script again."
    echo "See MARIADB_SETUP.md for detailed instructions."
    exit 0
fi
echo ""

# Apply migrations
echo "[5/6] Applying database migrations..."
python manage.py makemigrations
python manage.py migrate
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to apply migrations"
    echo "Please check:"
    echo "1. Database is running"
    echo "2. Database credentials are correct in settings.py"
    echo "3. You have created the database and user"
    exit 1
fi
echo "Migrations applied successfully!"
echo ""

# Setup groups
echo "[6/6] Setting up user groups and permissions..."
python manage.py setup_groups
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to setup groups"
    exit 1
fi
echo "Groups and permissions configured!"
echo ""

echo "============================================"
echo "Setup Complete!"
echo "============================================"
echo ""
echo "Next steps:"
echo "1. Create a superuser: python manage.py createsuperuser"
echo "2. Run the server: python manage.py runserver"
echo "3. Access admin at: http://127.0.0.1:8000/admin/"
echo ""
read -p "Would you like to create a superuser now? (y/n): " createuser
if [ "$createuser" = "y" ] || [ "$createuser" = "Y" ]; then
    echo ""
    python manage.py createsuperuser
fi
echo ""

echo "============================================"
echo "All done! You can now run:"
echo "  python manage.py runserver"
echo "============================================"
