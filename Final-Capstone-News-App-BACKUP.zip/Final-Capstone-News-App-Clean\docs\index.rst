Welcome to News Application's documentation!
=============================================

This is the comprehensive documentation for the Django News Application,
featuring role-based access control, REST API, and content management.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
